package com.example.teste2;

import android.os.Bundle;

public class AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
